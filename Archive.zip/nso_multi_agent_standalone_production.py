#!/usr/bin/env python3
"""
NSO Multi-Agent Network Manager - Production Version
===================================================

This script replicates the functionality of the NSO_python_multi-agend.ipynb notebook
for deployment on a production host with real NCS devices.

ADAPTATION NOTES:
================
1. NSO Environment: Updated to use /opt/ncs/current (standard production path)
2. Device Names: Update device names in the code for your real devices
3. Authentication: Update authgroup settings if different from 'cisco' authgroup
4. LLM Configuration: Update Azure OpenAI settings for your environment
5. Flask Port: Change port if needed (currently 5606)
6. SSL Certificates: Update certificate paths if using SSL

REQUIREMENTS:
============
- NSO server running with real devices connected
- Python packages: llama-index, llama-index-llms-azure-openai, flask
- Azure OpenAI API key configured
- NSO Python API accessible

USAGE:
======
python nso_multi_agent_standalone_production.py
"""

import os
import sys
import logging
import json
import base64
import requests
import asyncio
import subprocess
from datetime import datetime
from typing import List, Dict, Any, Optional

# =============================================================================
# CONFIGURATION SECTION - ADAPT THESE FOR YOUR ENVIRONMENT
# =============================================================================

# NSO Configuration - PRODUCTION SETTINGS
NSO_DIR = "/opt/ncs/current"  # Standard production NSO installation path
NSO_USER = "admin"                 # Change if using different NSO user
NSO_CONTEXT = "multi_agent_context"  # Change if needed

# Device Configuration - ADAPT THESE FOR YOUR REAL DEVICES
# Replace these with your actual device names
EXPECTED_DEVICES = []  # Empty list for dynamic discovery - update with your real device names
AUTHGROUP_NAME = "cisco"  # Change if using different authgroup

# Azure OpenAI Configuration - ADAPT THESE FOR YOUR ENVIRONMENT
# Cisco Azure OpenAI Configuration
CLIENT_ID = 'cG9jLXRyaWFsMjAyM09jdG9iZXIxNwff_540f3843f35f87eeb7b238fc2f8807'
CLIENT_SECRET = 'b-mQoS2NXZe4I15lVXtY7iBHCAg9u7ufZFx7MZiOHAFlzRBkFmOaenUI2buRpRBb'
TOKEN_URL = "https://id.cisco.com/oauth2/default/v1/token"
LLM_ENDPOINT = "https://chat-ai.cisco.com"
APPKEY = "egai-prd-wws-log-chat-data-analysis-1"

# Flask Configuration - ADAPT IF NEEDED
FLASK_HOST = "0.0.0.0"
FLASK_PORT = 5606
FLASK_DEBUG = False

# SSL Configuration - ADAPT IF USING SSL
USE_SSL = False  # Set to True if using SSL certificates
SSL_CERT_PATH = "./certs/cert.pem"  # Change to your certificate path
SSL_KEY_PATH = "./certs/key.pem"    # Change to your key path

# =============================================================================
# ENVIRONMENT SETUP
# =============================================================================

def setup_nso_environment():
    """Setup NSO environment variables and Python path"""
    print("🔧 Setting up NSO environment...")
    
    # Set NSO environment variables
    os.environ['NCS_DIR'] = NSO_DIR
    os.environ['DYLD_LIBRARY_PATH'] = f'{NSO_DIR}/lib'
    os.environ['PYTHONPATH'] = f'{NSO_DIR}/src/ncs/pyapi'
    
    # Add NSO Python API to Python path
    nso_pyapi_path = f'{NSO_DIR}/src/ncs/pyapi'
    if nso_pyapi_path not in sys.path:
        sys.path.insert(0, nso_pyapi_path)
    
    print(f"✅ NSO environment configured:")
    print(f"   - NCS_DIR: {NSO_DIR}")
    print(f"   - PYTHONPATH: {nso_pyapi_path}")
    
    return True

def get_cisco_token():
    """Get Cisco OAuth token for LLM access"""
    try:
        # Create base64 encoded auth key
        auth_key = base64.b64encode(f"{CLIENT_ID}:{CLIENT_SECRET}".encode("utf-8")).decode("utf-8")
        
        headers = {
            "Accept": "*/*",
            "Content-Type": "application/x-www-form-urlencoded",
            "Authorization": f"Basic {auth_key}",
        }
        
        # Make a POST request to retrieve the token
        token_response = requests.post(TOKEN_URL, headers=headers, data="grant_type=client_credentials")
        
        if token_response.status_code == 200:
            token = token_response.json().get("access_token")
            print("✅ Cisco OAuth token obtained successfully")
            return token
        else:
            print(f"❌ Failed to get Cisco token: {token_response.status_code} - {token_response.text}")
            return None
            
    except Exception as e:
        print(f"❌ Error getting Cisco token: {e}")
        return None

def setup_logging():
    """Setup logging configuration"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler('nso_multi_agent.log')
        ]
    )
    return logging.getLogger(__name__)

# =============================================================================
# NSO CONNECTION AND DEVICE MANAGEMENT
# =============================================================================

class NSOConnection:
    """Handles NSO connection and basic operations"""
    
    def __init__(self):
        self.maapi = None
        self.transaction = None
        self.root = None
        self.logger = logging.getLogger(__name__)
    
    def connect(self):
        """Connect to NSO and initialize session"""
        try:
            # Import NSO modules
            import ncs
            import ncs.maapi as maapi
            import ncs.maagic as maagic
            
            # Create MAAPI connection
            self.maapi = maapi.Maapi()
            self.maapi.start_user_session(NSO_USER, NSO_CONTEXT)
            self.transaction = self.maapi.start_write_trans()
            self.root = maagic.get_root(self.transaction)
            
            self.logger.info("✅ NSO connection established successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"❌ NSO connection failed: {e}")
            return False
    
    def disconnect(self):
        """Disconnect from NSO"""
        try:
            if self.transaction:
                self.transaction.finish()
            if self.maapi:
                self.maapi.close()
            self.logger.info("✅ NSO connection closed")
        except Exception as e:
            self.logger.error(f"❌ Error closing NSO connection: {e}")
    
    def get_devices(self) -> List[str]:
        """Get list of all devices"""
        try:
            devices = []
            for device in self.root.devices.device:
                devices.append(device.name)
            return devices
        except Exception as e:
            self.logger.error(f"❌ Error getting devices: {e}")
            return []
    
    def get_device_info(self, device_name: str) -> Dict[str, Any]:
        """Get detailed information about a specific device"""
        try:
            device = self.root.devices.device[device_name]
            info = {
                'name': device.name,
                'address': str(device.address),
                'port': str(device.port),
                'authgroup': str(device.authgroup),
                'device_type': str(device.device_type),
                'oper_state': 'unknown',
                'admin_state': 'unknown'
            }
            
            # Try to get operational state if available
            try:
                info['oper_state'] = str(device.oper_state)
            except:
                pass
            
            # Try to get admin state if available
            try:
                info['admin_state'] = str(device.admin_state)
            except:
                pass
            
            return info
        except Exception as e:
            self.logger.error(f"❌ Error getting device info for {device_name}: {e}")
            return {}
    
    def execute_command_via_cli(self, device_name: str, command: str) -> str:
        """Execute a command via NSO CLI as fallback"""
        try:
            # Set up NSO environment
            env = os.environ.copy()
            env['NCS_DIR'] = NSO_DIR
            env['DYLD_LIBRARY_PATH'] = f'{NSO_DIR}/lib'
            env['PYTHONPATH'] = f'{NSO_DIR}/src/ncs/pyapi'
            
            # Build NSO CLI command
            ncs_cli_cmd = [
                f'{NSO_DIR}/bin/ncs_cli',
                '-u', 'admin',
                '-C',
                f'devices device {device_name} live-status cisco-ios-xr-stats:exec any "{command}"'
            ]
            
            # Execute command
            result = subprocess.run(
                ncs_cli_cmd,
                capture_output=True,
                text=True,
                env=env,
                timeout=30
            )
            
            if result.returncode == 0:
                return result.stdout.strip()
            else:
                return f"CLI execution failed: {result.stderr.strip()}"
                
        except subprocess.TimeoutExpired:
            return "Command execution timed out"
        except Exception as e:
            return f"CLI execution error: {e}"

    def execute_command(self, device_name: str, command: str) -> str:
        """Execute a command on a specific device"""
        try:
            device = self.root.devices.device[device_name]
            
            # Try different command execution methods based on NSO version
            try:
                # Method 1: Direct execution (most common)
                result = device.live_status.cisco_ios_xr_stats__exec.any.get(command)
                return str(result)
            except:
                try:
                    # Method 2: Using action as function
                    action = device.live_status.cisco_ios_xr_stats__exec.any
                    result = action(command)
                    return str(result)
                except:
                    # Method 3: Try with different action path
                    try:
                        result = device.live_status.cisco_ios_xr_stats__exec.any(command)
                        return str(result)
                    except:
                        # Method 4: Try CLI execution as fallback
                        try:
                            cli_result = self.execute_command_via_cli(device_name, command)
                            if "CLI execution failed" not in cli_result and "CLI execution error" not in cli_result:
                                return f"Command executed via NSO CLI:\n{cli_result}"
                        except:
                            pass
                        
                        # Method 5: Provide helpful information when all methods fail
                        device_info = self.get_device_info(device_name)
                        return f"""Command execution not available for {device_name}.

Device Information:
- Name: {device_info.get('name', 'unknown')}
- Address: {device_info.get('address', 'unknown')}
- Port: {device_info.get('port', 'unknown')}
- Authgroup: {device_info.get('authgroup', 'unknown')}
- Device Type: {device_info.get('device_type', 'unknown')}
- Operational State: {device_info.get('oper_state', 'unknown')}
- Admin State: {device_info.get('admin_state', 'unknown')}

Note: Command execution through Python API may not be fully supported for this device.
You can execute commands directly using NSO CLI:
ncs_cli -u admin -C "devices device {device_name} live-status cisco-ios-xr-stats:exec any \\"{command}\\""
"""
        except Exception as e:
            self.logger.error(f"❌ Error executing command '{command}' on {device_name}: {e}")
            return f"Error executing command: {e}"

# =============================================================================
# NSO TOOLS FOR LLAMAINDEX
# =============================================================================

def create_nso_tools(nso_conn: NSOConnection):
    """Create NSO tools for LlamaIndex agent"""
    
    def show_all_devices() -> str:
        """Show all devices in NSO"""
        try:
            devices = nso_conn.get_devices()
            if not devices:
                return "No devices found in NSO"
            
            result = f"Found {len(devices)} devices in NSO:\n"
            for device in devices:
                info = nso_conn.get_device_info(device)
                result += f"- {device}: {info.get('oper_state', 'unknown')} ({info.get('address', 'unknown')})\n"
            
            return result
        except Exception as e:
            return f"Error getting devices: {e}"
    
    def get_device_info(device_name: str) -> str:
        """Get detailed information about a specific device"""
        try:
            info = nso_conn.get_device_info(device_name)
            if not info:
                return f"Device '{device_name}' not found"
            
            result = f"Device Information for {device_name}:\n"
            for key, value in info.items():
                result += f"- {key}: {value}\n"
            
            return result
        except Exception as e:
            return f"Error getting device info: {e}"
    
    def execute_command_on_device(device_name: str, command: str) -> str:
        """Execute a command on a specific device"""
        try:
            result = nso_conn.execute_command(device_name, command)
            return f"Command '{command}' executed on {device_name}:\n{result}"
        except Exception as e:
            return f"Error executing command: {e}"
    
    def get_device_version(device_name: str) -> str:
        """Get version information for a specific device"""
        try:
            result = nso_conn.execute_command(device_name, "show version")
            return f"Version information for {device_name}:\n{result}"
        except Exception as e:
            return f"Error getting version: {e}"
    
    def check_device_status(device_name: str) -> str:
        """Check the operational status of a device"""
        try:
            info = nso_conn.get_device_info(device_name)
            if not info:
                return f"Device '{device_name}' not found"
            
            status = info.get('oper_state', 'unknown')
            admin_state = info.get('admin_state', 'unknown')
            
            return f"Device {device_name} Status:\n- Operational State: {status}\n- Admin State: {admin_state}"
        except Exception as e:
            return f"Error checking device status: {e}"
    
    return {
        'show_all_devices': show_all_devices,
        'get_device_info': get_device_info,
        'execute_command_on_device': execute_command_on_device,
        'get_device_version': get_device_version,
        'check_device_status': check_device_status
    }

# =============================================================================
# LLAMAINDEX AGENT SETUP
# =============================================================================

def setup_llamaindex_agent(nso_tools: Dict):
    """Setup LlamaIndex agent with NSO tools"""
    try:
        # Import LlamaIndex modules
        from llama_index.core import Settings
        from llama_index.core.callbacks import CallbackManager, LlamaDebugHandler
        from llama_index.core.tools import FunctionTool
        from llama_index.core.agent import ReActAgent
        from llama_index.llms.azure_openai import AzureOpenAI
        
        # Setup logging
        logging.basicConfig(
            stream=sys.stdout, level=logging.INFO
        )  # logging.DEBUG for more verbose output
        logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))
        
        # Get Cisco OAuth token
        print("🔐 Getting Cisco OAuth token...")
        cisco_token = get_cisco_token()
        if not cisco_token:
            print("❌ Failed to get Cisco token")
            return None
        
        # Setup callback manager
        llama_debug = LlamaDebugHandler(print_trace_on_end=True)
        callback_manager = CallbackManager([llama_debug])
        Settings.callback_manager = callback_manager
        
        # Setup Cisco Azure OpenAI LLM
        print("🤖 Setting up Cisco Azure OpenAI LLM...")
        llm = AzureOpenAI(
            model="gpt-4",  # Use gpt-4 model
            deployment_name="gpt-4",  # Deployment name
            api_key=cisco_token,  # Use Cisco token as API key
            azure_endpoint=LLM_ENDPOINT,  # Cisco endpoint
            api_version="2024-02-15-preview",  # API version
            temperature=0.1,
            # Add Cisco-specific headers
            additional_kwargs={
                "headers": {
                    "Authorization": f"Bearer {cisco_token}",
                    "appkey": APPKEY
                }
            }
        )
        
        # Create FunctionTool objects
        tools = []
        for tool_name, tool_func in nso_tools.items():
            tool = FunctionTool.from_defaults(
                fn=tool_func,
                name=tool_name,
                description=f"NSO tool: {tool_name}"
            )
            tools.append(tool)
        
        # Create ReActAgent
        agent = ReActAgent(
            tools=tools,
            llm=llm,
            verbose=True,
            max_iterations=1000
        )
        
        print(f"✅ LlamaIndex agent created with {len(tools)} NSO tools")
        return agent
        
    except Exception as e:
        print(f"❌ Error setting up LlamaIndex agent: {e}")
        return None

# =============================================================================
# FLASK WEB INTERFACE
# =============================================================================

def create_flask_app(agent, nso_tools, nso_conn):
    """Create Flask web application"""
    try:
        from flask import Flask, request, render_template_string, redirect, url_for
        
        app = Flask(__name__)
        
        # HTML template for the web interface
        form_template = """
        <!doctype html>
        <html lang="en">
        <head>
          <meta charset="utf-8">
          <title>NSO Multi-Agent Network Manager</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              margin: 20px;
              background-color: #f5f5f5;
            }
            .container {
              max-width: 800px;
              margin: 0 auto;
              background-color: white;
              padding: 20px;
              border-radius: 8px;
              box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            h1 {
              font-size: 28px;
              color: #333;
              text-align: center;
              margin-bottom: 30px;
            }
            .status {
              background-color: #e8f5e8;
              padding: 15px;
              border-radius: 6px;
              margin-bottom: 20px;
              border-left: 4px solid #4CAF50;
            }
            form {
              margin-bottom: 20px;
            }
            textarea {
              width: 100%;
              height: 60px;
              padding: 15px;
              font-size: 16px;
              border: 2px solid #ddd;
              border-radius: 6px;
              resize: vertical;
              box-sizing: border-box;
            }
            input[type="submit"] {
              padding: 12px 24px;
              background-color: #4CAF50;
              color: white;
              border: none;
              border-radius: 6px;
              cursor: pointer;
              font-size: 16px;
              margin-top: 10px;
            }
            input[type="submit"]:hover {
              background-color: #45a049;
            }
            pre {
              background-color: #f8f9fa;
              padding: 20px;
              border-radius: 6px;
              white-space: pre-wrap;
              word-wrap: break-word;
              font-family: 'Courier New', Courier, monospace;
              font-size: 14px;
              border-left: 4px solid #4CAF50;
              margin-top: 20px;
            }
            .reset-btn {
              background-color: #ff6b6b;
              margin-left: 10px;
            }
            .reset-btn:hover {
              background-color: #ff5252;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <h1>🤖 NSO Multi-Agent Network Manager</h1>
            
            <div class="status">
              <strong>✅ Status:</strong> NSO Agent is ready with your production devices
            </div>
            
            <form method="POST">
              <textarea name="text" placeholder="Ask me anything about your network devices... (e.g., 'Show me all devices', 'What is the status of device1?', 'Execute show version on device2')" required></textarea><br>
              <input type="submit" value="Query Agent">
              <input type="submit" name="reset" value="Reset Agent" class="reset-btn" formaction="/reset-agent">
            </form>
            
            {% if response %}
            <h3>🤖 Agent Response:</h3>
            <pre>{{ response }}</pre>
            {% endif %}
          </div>
        </body>
        </html>
        """
        
        @app.route("/", methods=["GET", "POST"])
        def home():
            response = None
            if request.method == "POST":
                query_text = request.form.get("text", "")
                if query_text and agent:
                    try:
                        # Try to run the agent synchronously
                        response = agent.run(query_text)
                    except Exception as e:
                        # Enhanced fallback mechanism for better query understanding
                        try:
                            query_lower = query_text.lower()
                            
                            # Get all available devices dynamically
                            available_devices = nso_conn.get_devices()
                            
                            # Device status queries
                            if any(word in query_lower for word in ['status', 'state', 'operational', 'admin']):
                                if 'all' in query_lower or 'devices' in query_lower:
                                    # Get status for all devices
                                    devices = nso_conn.get_devices()
                                    response = "Device Status Summary:\n"
                                    for device in devices:
                                        info = nso_conn.get_device_info(device)
                                        response += f"- {device}: {info.get('oper_state', 'unknown')} (Admin: {info.get('admin_state', 'unknown')})\n"
                                else:
                                    # Get status for specific device
                                    device_name = None
                                    for device in available_devices:
                                        if device.lower() in query_lower:
                                            device_name = device
                                            break
                                    if device_name:
                                        info = nso_conn.get_device_info(device_name)
                                        response = f"Device {device_name} Status:\n"
                                        response += f"- Operational State: {info.get('oper_state', 'unknown')}\n"
                                        response += f"- Admin State: {info.get('admin_state', 'unknown')}\n"
                                        response += f"- Address: {info.get('address', 'unknown')}\n"
                                        response += f"- Port: {info.get('port', 'unknown')}\n"
                                    else:
                                        response = f"Please specify which device you want status for. Available devices: {', '.join(available_devices)}"
                            
                            # Interface queries
                            elif any(word in query_lower for word in ['interface', 'interfaces', 'int', 'port']):
                                device_name = None
                                for device in available_devices:
                                    if device.lower() in query_lower:
                                        device_name = device
                                        break
                                if device_name:
                                    # Try to get interface information
                                    try:
                                        interface_result = nso_conn.execute_command(device_name, "show ipv4 int brief")
                                        response = f"Interfaces on {device_name}:\n{interface_result}"
                                    except:
                                        response = f"Interface information for {device_name}:\n"
                                        response += "Command execution not available. Device info:\n"
                                        info = nso_conn.get_device_info(device_name)
                                        for key, value in info.items():
                                            response += f"- {key}: {value}\n"
                                else:
                                    response = f"Please specify which device you want interface information for. Available devices: {', '.join(available_devices)}"
                            
                            # Version queries
                            elif any(word in query_lower for word in ['version', 'software', 'ios', 'firmware']):
                                device_name = None
                                for device in available_devices:
                                    if device.lower() in query_lower:
                                        device_name = device
                                        break
                                if device_name:
                                    try:
                                        version_result = nso_conn.execute_command(device_name, "show version")
                                        response = f"Version information for {device_name}:\n{version_result}"
                                    except:
                                        response = f"Version information for {device_name}:\n"
                                        response += "Command execution not available. Device info:\n"
                                        info = nso_conn.get_device_info(device_name)
                                        for key, value in info.items():
                                            response += f"- {key}: {value}\n"
                                else:
                                    response = f"Please specify which device you want version information for. Available devices: {', '.join(available_devices)}"
                            
                            # General device queries (moved to end to avoid conflicts)
                            elif any(word in query_lower for word in ['devices', 'device', 'list']) and not any(word in query_lower for word in ['status', 'interface', 'version', 'cpu', 'memory', 'usage', 'process']):
                                devices = nso_conn.get_devices()
                                response = f"Available Devices ({len(devices)}):\n"
                                for device in devices:
                                    info = nso_conn.get_device_info(device)
                                    response += f"- {device}: {info.get('oper_state', 'unknown')} ({info.get('address', 'unknown')}:{info.get('port', 'unknown')})\n"
                            
                            # CPU/Memory queries
                            elif any(word in query_lower for word in ['cpu', 'memory', 'process', 'performance', 'usage']):
                                device_name = None
                                for device in available_devices:
                                    if device.lower() in query_lower:
                                        device_name = device
                                        break
                                if device_name:
                                    try:
                                        cpu_result = nso_conn.execute_command(device_name, "show processes cpu")
                                        response = f"CPU information for {device_name}:\n{cpu_result}"
                                    except:
                                        response = f"CPU/Memory information for {device_name}:\n"
                                        response += "Command execution not available. Device info:\n"
                                        info = nso_conn.get_device_info(device_name)
                                        for key, value in info.items():
                                            response += f"- {key}: {value}\n"
                                else:
                                    response = f"Please specify which device you want CPU/memory information for. Available devices: {', '.join(available_devices)}"
                            
                            # Default response
                            else:
                                response = f"I can help you with:\n"
                                response += f"- Device status and information\n"
                                response += f"- Interface details\n"
                                response += f"- Version information\n"
                                response += f"- CPU and memory usage\n"
                                response += f"- General device queries\n\n"
                                response += f"Available devices: {', '.join(available_devices)}\n"
                                response += f"Try asking: 'Show me all devices status' or 'What interfaces are on [device_name]?'"
                                
                        except Exception as e2:
                            response = f"Error processing query: {e2}"
            return render_template_string(form_template, response=response)
        
        @app.route("/reset-agent", methods=["POST"])
        def reset_agent():
            return redirect(url_for("home"))
        
        return app
        
    except Exception as e:
        print(f"❌ Error creating Flask app: {e}")
        return None

# =============================================================================
# MAIN EXECUTION
# =============================================================================

def main():
    """Main execution function"""
    print("🚀 Starting NSO Multi-Agent Network Manager - Production Version")
    print("=" * 70)
    
    # Setup logging
    logger = setup_logging()
    
    # Setup NSO environment
    if not setup_nso_environment():
        print("❌ Failed to setup NSO environment")
        return False
    
    # Initialize NSO connection
    nso_conn = NSOConnection()
    if not nso_conn.connect():
        print("❌ Failed to connect to NSO")
        return False
    
    try:
        # Test NSO connection by listing devices
        print("\n📱 Testing NSO connection...")
        devices = nso_conn.get_devices()
        print(f"✅ Found {len(devices)} devices: {', '.join(devices)}")
        
        # Check if expected devices are present (if specified)
        if EXPECTED_DEVICES:
            missing_devices = [d for d in EXPECTED_DEVICES if d not in devices]
            if missing_devices:
                print(f"⚠️  Warning: Expected devices not found: {missing_devices}")
                print(f"   Available devices: {devices}")
                print("   Please update EXPECTED_DEVICES in the configuration section")
        else:
            print("ℹ️  Using dynamic device discovery (EXPECTED_DEVICES is empty)")
        
        # Create NSO tools
        print("\n🔧 Creating NSO tools...")
        nso_tools = create_nso_tools(nso_conn)
        print(f"✅ Created {len(nso_tools)} NSO tools")
        
        # Setup LlamaIndex agent
        print("\n🤖 Setting up LlamaIndex agent...")
        agent = setup_llamaindex_agent(nso_tools)
        if not agent:
            print("❌ Failed to setup LlamaIndex agent")
            return False
        
        # Test agent with a simple query
        print("\n🧪 Testing agent...")
        try:
            # Test the NSO tools directly instead of the agent
            test_response = nso_tools['show_all_devices']()
            print(f"✅ NSO tools test successful")
        except Exception as e:
            print(f"⚠️  NSO tools test failed: {e}")
            print("   Continuing anyway...")
        
        # Create and run Flask app
        print("\n🌐 Starting Flask web interface...")
        app = create_flask_app(agent, nso_tools, nso_conn)
        if not app:
            print("❌ Failed to create Flask app")
            return False
        
        print(f"📱 Access the web interface at: http://localhost:{FLASK_PORT}")
        print("🔒 Press CTRL+C to stop the server")
        
        # Run Flask app
        if USE_SSL:
            app.run(
                host=FLASK_HOST,
                port=FLASK_PORT,
                debug=FLASK_DEBUG,
                ssl_context=(SSL_CERT_PATH, SSL_KEY_PATH)
            )
        else:
            app.run(
                host=FLASK_HOST,
                port=FLASK_PORT,
                debug=FLASK_DEBUG
            )
        
        return True
        
    except KeyboardInterrupt:
        print("\n🛑 Shutting down...")
        return True
        
    except Exception as e:
        logger.error(f"❌ Unexpected error: {e}")
        return False
        
    finally:
        # Cleanup
        nso_conn.disconnect()

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
